module.exports = {
  content: ["./src/**/*.{js,jsx,ts,tsx}"], // Ensure it scans your project files
  theme: {
    extend: {},
  },
  plugins: [],
};
